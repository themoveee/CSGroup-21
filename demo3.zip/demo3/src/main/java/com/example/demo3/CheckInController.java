package com.example.demo3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CheckInController extends Util implements Initializable {

        @FXML
        private Button back;

        @FXML
        private Button btnClear;

        @FXML
        private Button btnSubmit;

        @FXML
        private TextField txtaddress;

        @FXML
        private PasswordField txtccode;

        @FXML
        private TextField txtcnum;

        @FXML
        private TextField txtemail;

        @FXML
        private TextField txtid;

        @FXML
        private TextField txtname;

        @FXML
        private TextField txtphone;

    @FXML
    private ComboBox<String> RType;



    @FXML
    void submit(ActionEvent event) throws SQLException, IOException, ClassNotFoundException {
        String name = txtname.getText();
        String phone = txtphone.getText();
        String email = txtemail.getText();
        String date = txtid.getText();
        String address = txtaddress.getText();
        String ccnum = txtcnum.getText();
        String cvc = txtccode.getText();
        String room_type = RType.getValue();
        DBAccess conn = new DBAccess();

        if (conn.checkin(name, phone, email, date, address, ccnum, cvc, room_type) == 1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setContentText("CHECKED IN SUCCESSFULLY");
            alert.setHeaderText(null);
            alert.showAndWait();

            txtname.clear();
            txtphone.clear();
            txtemail.clear();
            txtid.clear();
            txtaddress.clear();
            txtcnum.clear();
            txtccode.clear();

            Parent root  = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
            Stage window = (Stage) btnSubmit.getScene().getWindow();
            window.setScene(new Scene(root));
            window.setTitle("Main Dashboard");
            window.show();
        }

//        if (txtname.getText().isBlank() == false && txtccode.getText().isBlank() == false &&
//        txtcnum.getText().isBlank() == false && txtid.getText().isBlank()== false &&
//        txtaddress.getText().isBlank() == false && txtccode.getText().isBlank() == false &&
//        txtemail.getText().isBlank() == false && txtphone.getText().isBlank() == false && {
//                Alert alert = new Alert(Alert.AlertType.ERROR);
//        alert.setContentText("Please fill all fields");
//        alert.setHeaderText(null);
//        alert.showAndWait();
//
//        }

        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Wrong Username or Password, retype!!!");
            alert.setHeaderText(null);
            alert.showAndWait();
        }

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        RType.getItems().addAll("Standard", "Deluxe");
    }

    public void jusback() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
        Stage window = (Stage) back.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }



    }



