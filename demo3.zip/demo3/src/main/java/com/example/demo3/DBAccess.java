package com.example.demo3;

import com.example.demo3.model.Customer;

import java.sql.*;

public class DBAccess {
    private final String DB_NAME = "hotel_padi";
    private final String USERNAME = "root";
    private final String PASSWORD = "1973";
    private PreparedStatement pst;
    private ResultSet rs;
    private Connection con;

    public DBAccess() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DB_NAME, USERNAME, PASSWORD);
    }

    public int registerUser(Customer customer) throws SQLException {
        String query = "INSERT INTO customer VALUE(null, ?, ?, ?, ?)";
        pst = con.prepareStatement(query);
        pst.setString(1, customer.getName());
        pst.setString(2, customer.getGender());
        pst.setString(3, customer.getEmail());
        pst.setString(4, customer.getPassword());
        return pst.executeUpdate();
    }

    public int login(String username, String password) throws SQLException {
        pst = con.prepareStatement("SELECT * FROM customer WHERE username = ? AND password = ?");
        pst.setString(1, username);
        pst.setString(2,password);
        rs = pst.executeQuery();
        if(rs.next()){
            return 1;
        }else{
            return 0;
        }
    }


    public int checkin(String name, String phone, String email, String date,
                       String address, String ccnum, String cvc, String room_type) throws SQLException {
        String query = " INSERT INTO `hotel_padi`.`check_in`(`idcheck`,`name`,`phone`,`email`,`date`,`address`,`ccnum`,`cvc`,`room_type`)" +
                "VALUES (null, ?, ?, ?, ?, ?, ?, ?, ?)";
        pst = con.prepareStatement(query);
        pst.setString(1, name);
        pst.setString(2, phone);
        pst.setString(3, email);
        pst.setString(4, date);
        pst.setString(5, address);
        pst.setString(6, ccnum);
        pst.setString(7, cvc);
        pst.setString(8, room_type);

        return pst.executeUpdate();
    }


    public int checkout(String name, String room_number, String date) throws SQLException {
        String query = " INSERT INTO `hotel_padi`.`check_out`(`idcheck_out`, `name`,`room_number`,`date`) VALUES (null, ?, ?, ?)";
        pst = con.prepareStatement(query);
        pst.setString(1, name);
        pst.setString(2, date);
        pst.setString(3, room_number);

        return pst.executeUpdate();
    }


    public static void viewfewdata(int Id, String Name, String Contact, String Date, String Room_Type) {
        Connection connection = null;
        PreparedStatement insert = null;
        PreparedStatement display = null;
        ResultSet resultSet = null;

        try {
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_padi", "root", "1973");
        display = connection.prepareStatement("SELECT id, name, contact, date, room_type FROM check_in");
        display.setInt(1, Id);
        display.setString(2, Name);
        display.setString(3, Contact);
        display.setString(4, Date);
        display.setString(5, Room_Type);
        resultSet = display.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }


    }


    }


