package com.example.demo3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboardController extends Util{


    @FXML
    private Button btnCheckIn;
    @FXML
    private Button btnCheckOut;
    @FXML
    private Button btnRooms;

    @FXML
    private Button logout;

    public void connectPage(ActionEvent event) throws IOException{
        if (event.getSource().equals(btnCheckIn)){
            Parent root = FXMLLoader.load(getClass().getResource("CheckIn.fxml"));
            Stage window = (Stage) btnCheckIn.getScene().getWindow();
            window.setScene(new Scene(root));
            window.show();
            //loadFile("CheckIn.fxml", HelloApplication.getWindow());
        } else if (event.getSource().equals(btnCheckOut)) {
            Parent root = FXMLLoader.load(getClass().getResource("Checkout.fxml"));
            Stage window = (Stage) btnCheckOut.getScene().getWindow();
            window.setScene(new Scene(root));
            window.show();
            //            loadFile("CheckOut.fxml", HelloApplication.getWindow());
        } else if (event.getSource().equals(btnRooms)) {
            Parent root = FXMLLoader.load(getClass().getResource("Rooms.fxml"));
            Stage window = (Stage) btnRooms.getScene().getWindow();
            window.setScene(new Scene(root));
            window.show();
            //loadFile("Rooms.fxml", HelloApplication.getWindow());
        }
    }

    public void checkinpage() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("CheckIn.fxml"));
        Stage window = (Stage) btnCheckIn.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }

    public void justgoback() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Stage window = (Stage) btnRooms.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }

    public void closepage() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Stage window = (Stage) logout.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
    }


}
