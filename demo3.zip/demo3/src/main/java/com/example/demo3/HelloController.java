package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class HelloController extends Util{

    @FXML
    private Button btnSignUp;

    @FXML
    private Button btn_enter;

    @FXML
    private TextField txtUserName;

    @FXML
    private TextField txtPassword;

    public void directToSignUp() throws IOException {
        Parent root  = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
        Stage window = (Stage) btnSignUp.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("Sign up Page");
        window.show();
    }

    public void login() throws SQLException, ClassNotFoundException, IOException {
        DBAccess dba = new DBAccess();
        if(dba.login(txtUserName.getText(), txtPassword.getText()) == 1){
            Parent root  = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
            Stage window = (Stage) btnSignUp.getScene().getWindow();
            window.setScene(new Scene(root));
            window.setTitle("Sign up Page");
            window.show();
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Username and Password Incorrect!!");
            alert.setHeaderText(null);
            alert.showAndWait();
        }
    }

    public void exit(){
        System.exit(0);
    }
}