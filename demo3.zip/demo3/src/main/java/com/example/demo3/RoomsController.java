package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;

import java.net.URL;
import java.util.ResourceBundle;

public class RoomsController extends Util implements Initializable {

    @FXML
    private TableColumn<?, ?> contactcol;

    @FXML
    private TableColumn<?, id> datecol;

    @FXML
    private Button goback;

    @FXML
    private TableColumn<?, ?> idcol;

    @FXML
    private TableColumn<?, ?> namecol;

    @FXML
    private TableColumn<?, ?> roomcol;

    @FXML
    private Button viewee;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}

