package com.example.demo3;

import com.example.demo3.model.Customer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class SignUpController extends Util implements Initializable {
    @FXML
    private ComboBox<String> cbGender;

    @FXML
    private TextField txtUserName;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnCreate;

    @FXML
    private TextField txtEmail;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        cbGender.getItems().addAll("Male", "Female", "Other");
    }

    public void createUser() throws SQLException, ClassNotFoundException, IOException {
        Customer customer = new Customer(txtUserName.getText(), cbGender.getValue(),
                txtEmail.getText(), txtPassword.getText());
        DBAccess dba = new DBAccess();
        if (dba.registerUser(customer) == 1){
            Parent root  = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
            Stage window = (Stage) btnCreate.getScene().getWindow();
            window.setScene(new Scene(root));
            window.setTitle("Sign up Page");
            window.show();;
        }
    }
}
