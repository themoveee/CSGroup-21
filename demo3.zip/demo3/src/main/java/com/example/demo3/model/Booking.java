package com.example.demo3.model;

public class Booking {
    private int BookingId;
    private String BookingType;
    private String Date;

    public Booking() {
    }

    public Booking(String bookingType, String date) {
        BookingType = bookingType;
        Date = date;
    }

    public int getBookingId() {
        return BookingId;
    }

    public void setBookingId(int bookingId) {
        BookingId = bookingId;
    }

    public String getBookingType() {
        return BookingType;
    }

    public void setBookingType(String bookingType) {
        BookingType = bookingType;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
