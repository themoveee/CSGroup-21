package com.example.demo3.model;

public class Customer {
    private int CustomerId;
    private String Name;
    private String Gender;
    private String Email;
    private String Password;

    public Customer(String name, String gender, String email, String password) {
        Name = name;
        Gender = gender;
        Email = email;
        Password = password;
    }

    public Customer() {

    }

    public int getCustomerId() {
        return CustomerId;
    }

    public void setCustomerId(int customerId) {
        CustomerId = customerId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}


