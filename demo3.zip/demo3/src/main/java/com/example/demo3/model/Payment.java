package com.example.demo3.model;

public class Payment {
    private String PaymentType;
    private double Amount;
    private String Date;
    private int CustomerId;

    public Payment() {
    }

    public Payment(String paymentType, double amount, String date) {
        PaymentType = paymentType;
        Amount = amount;
        Date = date;

    }

    public String getPaymentType() {
        return PaymentType;
    }

    public void setPaymentType(String paymentType) {
        PaymentType = paymentType;
    }

    public double getAmount() {
        return Amount;
    }

    public void setAmount(double amount) {
        Amount = amount;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public int getCustomerId() {
        return CustomerId;
    }

    public void setCustomerId(int customerId) {
        CustomerId = customerId;
    }
}
